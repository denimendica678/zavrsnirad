﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace vjezbaZavrsniRad
{
    public partial class UpisUKalendar : Form
    {
        //kreirali smo varijablu tipa string - path koja na njeno pozivanje kreira datoteku Kalendar.xml na Desktopu lokalnog računala
        string path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Kalendari.xml");

        public UpisUKalendar()
        {
            InitializeComponent();

            DataSet ds1 = new DataSet();
            ds1.ReadXml(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Agencije.xml"));
            this.comboBoxAgencija.DataSource = ds1.Tables[0];
            this.comboBoxAgencija.DisplayMember = "Naziv";

            DataSet ds2 = new DataSet();
            ds2.ReadXml(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Brodovi.xml"));
            this.comboBoxImeBroda.DataSource = ds2.Tables[0];
            this.comboBoxImeBroda.DisplayMember = "Ime";

        }

        private void UpisUKalendar_Load(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            this.Hide();
            KalendarBrodova fm = new KalendarBrodova();
            fm.Show();
        }

        private void btnUnesiBrodUKalendar_Click(object sender, EventArgs e)
        {
            //kreiramo try catch zbog mogućnosti da na računalu ne postoji datoteka Kalendari.xml na Desktopu, te ako ne postoji kreira se nova
            try
            {

                //kreiramo varijablu Kalendari koja na poziv učitava datoteku kalendari
                var Kalendari = XDocument.Load(path);

                //
                var Kalendar = new XElement("Kalendar",
                            new XElement("Brod", comboBoxImeBroda.Text),
                            new XElement("Dolazak", dateTimePickerDolazak.Text),
                            new XElement("Odlazak", dateTimePickerOdlazak.Text),
                            new XElement("Agencija", comboBoxAgencija.Text),
                            new XElement("Stanje", comboBoxStanje.Text),
                            new XElement("Vez", comboBoxVez.Text));

                //
                Kalendari.Root.Add(Kalendar);

                //
                Kalendari.Save(path);
            }
            //ukoliko program ne pronađe datoteku Kalendari.xml, pokreće se sljedeći kod koji kreira Kalendari.xml datoteku
            catch (Exception ex)
            {
                //
                var Kalendari = new XDocument();

                //
                Kalendari.Add(new XElement("Kalendari"));

                //kreiramo varijablu Brod kojoj dodjeljujemo vrijednost izgleda i podataka koji će se naknadno spremiti u datoteku Brodovi.xml
                var Kalendar = new XElement("Kalendar",
                            new XElement("Brod", comboBoxImeBroda.Text),
                            new XElement("Dolazak", dateTimePickerDolazak.Text),
                            new XElement("Odlazak", dateTimePickerOdlazak.Text),
                            new XElement("Agencija", comboBoxAgencija.Text),
                            new XElement("Stanje", comboBoxStanje.Text),
                            new XElement("Vez", comboBoxVez.Text));

                //
                Kalendari.Root.Add(Kalendar);

                //
                Kalendari.Save(path);

            }

            //slijedećim dijelom koda upisani podatci sa prostoroa za unos podataka brišu se
            comboBoxImeBroda.Text = "";
            dateTimePickerDolazak.Text = "";
            dateTimePickerOdlazak.Text = "";
            comboBoxAgencija.Text = "";
            comboBoxStanje.Text = "";
            comboBoxVez.Text = "";
            
        }
    }
}
