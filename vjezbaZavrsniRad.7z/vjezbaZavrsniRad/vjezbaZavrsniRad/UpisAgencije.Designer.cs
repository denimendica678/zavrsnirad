﻿
namespace vjezbaZavrsniRad
{
    partial class UpisAgencije
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpisAgencije));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textAgencijaOib = new System.Windows.Forms.TextBox();
            this.textAgencijaBrRacuna = new System.Windows.Forms.TextBox();
            this.textAgencijaEmail = new System.Windows.Forms.TextBox();
            this.textNazivAgencije = new System.Windows.Forms.TextBox();
            this.btnUnesiNovuAgenciju = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBoxNaslov = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnNatragUA = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.textAgencijaOib);
            this.groupBox2.Controls.Add(this.textAgencijaBrRacuna);
            this.groupBox2.Controls.Add(this.textAgencijaEmail);
            this.groupBox2.Controls.Add(this.textNazivAgencije);
            this.groupBox2.Controls.Add(this.btnUnesiNovuAgenciju);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.richTextBoxNaslov);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.btnNatragUA);
            this.groupBox2.Location = new System.Drawing.Point(292, 85);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(830, 633);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // textAgencijaOib
            // 
            this.textAgencijaOib.Location = new System.Drawing.Point(153, 375);
            this.textAgencijaOib.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textAgencijaOib.Name = "textAgencijaOib";
            this.textAgencijaOib.Size = new System.Drawing.Size(165, 20);
            this.textAgencijaOib.TabIndex = 26;
            // 
            // textAgencijaBrRacuna
            // 
            this.textAgencijaBrRacuna.Location = new System.Drawing.Point(153, 419);
            this.textAgencijaBrRacuna.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textAgencijaBrRacuna.Name = "textAgencijaBrRacuna";
            this.textAgencijaBrRacuna.Size = new System.Drawing.Size(165, 20);
            this.textAgencijaBrRacuna.TabIndex = 27;
            // 
            // textAgencijaEmail
            // 
            this.textAgencijaEmail.Location = new System.Drawing.Point(153, 329);
            this.textAgencijaEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textAgencijaEmail.Name = "textAgencijaEmail";
            this.textAgencijaEmail.Size = new System.Drawing.Size(165, 20);
            this.textAgencijaEmail.TabIndex = 28;
            // 
            // textNazivAgencije
            // 
            this.textNazivAgencije.Location = new System.Drawing.Point(153, 290);
            this.textNazivAgencije.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textNazivAgencije.Name = "textNazivAgencije";
            this.textNazivAgencije.Size = new System.Drawing.Size(165, 20);
            this.textNazivAgencije.TabIndex = 25;
            // 
            // btnUnesiNovuAgenciju
            // 
            this.btnUnesiNovuAgenciju.BackColor = System.Drawing.Color.Silver;
            this.btnUnesiNovuAgenciju.Location = new System.Drawing.Point(40, 558);
            this.btnUnesiNovuAgenciju.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUnesiNovuAgenciju.Name = "btnUnesiNovuAgenciju";
            this.btnUnesiNovuAgenciju.Size = new System.Drawing.Size(173, 37);
            this.btnUnesiNovuAgenciju.TabIndex = 24;
            this.btnUnesiNovuAgenciju.Text = "UNESI";
            this.btnUnesiNovuAgenciju.UseVisualStyleBackColor = false;
            this.btnUnesiNovuAgenciju.Click += new System.EventHandler(this.btnUnesiNovuAgenciju_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 419);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "BROJ RAČUNA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 375);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "OIB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 332);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "E-MAIL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 290);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "NAZIV";
            // 
            // richTextBoxNaslov
            // 
            this.richTextBoxNaslov.BackColor = System.Drawing.Color.Azure;
            this.richTextBoxNaslov.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxNaslov.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.richTextBoxNaslov.ForeColor = System.Drawing.Color.Navy;
            this.richTextBoxNaslov.Location = new System.Drawing.Point(274, 27);
            this.richTextBoxNaslov.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBoxNaslov.Name = "richTextBoxNaslov";
            this.richTextBoxNaslov.Size = new System.Drawing.Size(556, 63);
            this.richTextBoxNaslov.TabIndex = 7;
            this.richTextBoxNaslov.Text = "UPIS AGENCIJE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::vjezbaZavrsniRad.Properties.Resources.naslovna_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(200, 34);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(418, 200);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnNatragUA
            // 
            this.btnNatragUA.BackColor = System.Drawing.Color.Silver;
            this.btnNatragUA.Location = new System.Drawing.Point(40, 34);
            this.btnNatragUA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnNatragUA.Name = "btnNatragUA";
            this.btnNatragUA.Size = new System.Drawing.Size(140, 72);
            this.btnNatragUA.TabIndex = 0;
            this.btnNatragUA.Text = "NATRAG";
            this.btnNatragUA.UseVisualStyleBackColor = false;
            this.btnNatragUA.Click += new System.EventHandler(this.btnNatragUA_Click);
            // 
            // UpisAgencije
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1443, 857);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UpisAgencije";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpisAgencije";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UpisAgencije_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textAgencijaOib;
        private System.Windows.Forms.TextBox textAgencijaBrRacuna;
        private System.Windows.Forms.TextBox textAgencijaEmail;
        public System.Windows.Forms.TextBox textNazivAgencije;
        private System.Windows.Forms.Button btnUnesiNovuAgenciju;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBoxNaslov;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnNatragUA;
    }
}