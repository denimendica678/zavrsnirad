﻿
namespace vjezbaZavrsniRad
{
    partial class UpisUKalendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnUnesiBrodUKalendar = new System.Windows.Forms.Button();
            this.comboBoxVez = new System.Windows.Forms.ComboBox();
            this.comboBoxVrstaBrodaUUK = new System.Windows.Forms.ComboBox();
            this.comboBoxAgencija = new System.Windows.Forms.ComboBox();
            this.comboBoxImeBroda = new System.Windows.Forms.ComboBox();
            this.dateTimePickerOdlazak = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerDolazak = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBoxNaslov = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnNatragUUKKB = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.btnUnesiBrodUKalendar);
            this.groupBox2.Controls.Add(this.comboBoxVez);
            this.groupBox2.Controls.Add(this.comboBoxVrstaBrodaUUK);
            this.groupBox2.Controls.Add(this.comboBoxAgencija);
            this.groupBox2.Controls.Add(this.comboBoxImeBroda);
            this.groupBox2.Controls.Add(this.dateTimePickerOdlazak);
            this.groupBox2.Controls.Add(this.dateTimePickerDolazak);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.richTextBoxNaslov);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.btnNatragUUKKB);
            this.groupBox2.Location = new System.Drawing.Point(337, 84);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(830, 633);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // btnUnesiBrodUKalendar
            // 
            this.btnUnesiBrodUKalendar.BackColor = System.Drawing.Color.Silver;
            this.btnUnesiBrodUKalendar.Location = new System.Drawing.Point(40, 558);
            this.btnUnesiBrodUKalendar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUnesiBrodUKalendar.Name = "btnUnesiBrodUKalendar";
            this.btnUnesiBrodUKalendar.Size = new System.Drawing.Size(173, 37);
            this.btnUnesiBrodUKalendar.TabIndex = 24;
            this.btnUnesiBrodUKalendar.Text = "UNESI";
            this.btnUnesiBrodUKalendar.UseVisualStyleBackColor = false;
            // 
            // comboBoxVez
            // 
            this.comboBoxVez.FormattingEnabled = true;
            this.comboBoxVez.Items.AddRange(new object[] {
            "V1",
            "V2",
            "V3",
            "V4",
            "V5",
            "V6",
            "V7",
            "V8",
            "V9",
            "V10"});
            this.comboBoxVez.Location = new System.Drawing.Point(153, 499);
            this.comboBoxVez.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxVez.Name = "comboBoxVez";
            this.comboBoxVez.Size = new System.Drawing.Size(168, 21);
            this.comboBoxVez.TabIndex = 23;
            // 
            // comboBoxVrstaBrodaUUK
            // 
            this.comboBoxVrstaBrodaUUK.FormattingEnabled = true;
            this.comboBoxVrstaBrodaUUK.Items.AddRange(new object[] {
            "Izletnicki",
            "Jahta",
            "Cruiser",
            "Ribarski"});
            this.comboBoxVrstaBrodaUUK.Location = new System.Drawing.Point(153, 458);
            this.comboBoxVrstaBrodaUUK.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxVrstaBrodaUUK.Name = "comboBoxVrstaBrodaUUK";
            this.comboBoxVrstaBrodaUUK.Size = new System.Drawing.Size(168, 21);
            this.comboBoxVrstaBrodaUUK.TabIndex = 22;
            // 
            // comboBoxAgencija
            // 
            this.comboBoxAgencija.FormattingEnabled = true;
            this.comboBoxAgencija.Items.AddRange(new object[] {
            "Sunny Way",
            "Simmor",
            "BWA",
            "Bez agencije"});
            this.comboBoxAgencija.Location = new System.Drawing.Point(153, 419);
            this.comboBoxAgencija.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgencija.Name = "comboBoxAgencija";
            this.comboBoxAgencija.Size = new System.Drawing.Size(168, 21);
            this.comboBoxAgencija.TabIndex = 21;
            // 
            // comboBoxImeBroda
            // 
            this.comboBoxImeBroda.FormattingEnabled = true;
            this.comboBoxImeBroda.Location = new System.Drawing.Point(153, 290);
            this.comboBoxImeBroda.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxImeBroda.Name = "comboBoxImeBroda";
            this.comboBoxImeBroda.Size = new System.Drawing.Size(168, 21);
            this.comboBoxImeBroda.TabIndex = 20;
            // 
            // dateTimePickerOdlazak
            // 
            this.dateTimePickerOdlazak.Location = new System.Drawing.Point(153, 375);
            this.dateTimePickerOdlazak.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerOdlazak.Name = "dateTimePickerOdlazak";
            this.dateTimePickerOdlazak.Size = new System.Drawing.Size(168, 20);
            this.dateTimePickerOdlazak.TabIndex = 18;
            // 
            // dateTimePickerDolazak
            // 
            this.dateTimePickerDolazak.Location = new System.Drawing.Point(153, 332);
            this.dateTimePickerDolazak.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePickerDolazak.Name = "dateTimePickerDolazak";
            this.dateTimePickerDolazak.Size = new System.Drawing.Size(168, 20);
            this.dateTimePickerDolazak.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 419);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "AGENCIJA";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 461);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "VRSTA BRODA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 499);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "VEZ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 375);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "ODLAZAK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 332);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "DOLAZAK";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 290);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "BROD";
            // 
            // richTextBoxNaslov
            // 
            this.richTextBoxNaslov.BackColor = System.Drawing.Color.Azure;
            this.richTextBoxNaslov.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxNaslov.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.richTextBoxNaslov.ForeColor = System.Drawing.Color.Navy;
            this.richTextBoxNaslov.Location = new System.Drawing.Point(269, 26);
            this.richTextBoxNaslov.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBoxNaslov.Name = "richTextBoxNaslov";
            this.richTextBoxNaslov.Size = new System.Drawing.Size(556, 63);
            this.richTextBoxNaslov.TabIndex = 7;
            this.richTextBoxNaslov.Text = "UPIS U KALENDAR";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::vjezbaZavrsniRad.Properties.Resources.naslovna_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(250, 34);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(418, 200);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnNatragUUKKB
            // 
            this.btnNatragUUKKB.BackColor = System.Drawing.Color.Silver;
            this.btnNatragUUKKB.Location = new System.Drawing.Point(40, 34);
            this.btnNatragUUKKB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnNatragUUKKB.Name = "btnNatragUUKKB";
            this.btnNatragUUKKB.Size = new System.Drawing.Size(140, 72);
            this.btnNatragUUKKB.TabIndex = 0;
            this.btnNatragUUKKB.Text = "NATRAG";
            this.btnNatragUUKKB.UseVisualStyleBackColor = false;
            this.btnNatragUUKKB.Click += new System.EventHandler(this.btnBack1_Click);
            // 
            // UpisUKalendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1443, 857);
            this.Controls.Add(this.groupBox2);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UpisUKalendar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Upis broda u kalendar";
            this.Load += new System.EventHandler(this.UpisUKalendar_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBoxNaslov;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnNatragUUKKB;
        private System.Windows.Forms.DateTimePicker dateTimePickerOdlazak;
        private System.Windows.Forms.DateTimePicker dateTimePickerDolazak;
        private System.Windows.Forms.ComboBox comboBoxImeBroda;
        private System.Windows.Forms.ComboBox comboBoxVez;
        private System.Windows.Forms.ComboBox comboBoxVrstaBrodaUUK;
        private System.Windows.Forms.ComboBox comboBoxAgencija;
        private System.Windows.Forms.Button btnUnesiBrodUKalendar;
    }
}