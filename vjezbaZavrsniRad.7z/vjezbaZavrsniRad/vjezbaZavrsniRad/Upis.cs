﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;

namespace vjezbaZavrsniRad
{
    public partial class Upis : Form
    {

        string path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Brodovi.xml");
        

        public Upis()
        {
            InitializeComponent();

        }

        private void Upis_Load(object sender, EventArgs e)
        {
           
        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpisBrodova fm = new UpisBrodova();
            fm.Show();

           
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                var Brodovi = XDocument.Load(path);

                var Brod = new XElement("Brod",
                        new XElement("Ime", textBoxImeBroda.Text),
                        new XElement("Imo", textBoxImo.Text),
                        new XElement("Duzina", textBoxDuzina.Text),
                        new XElement("Sirina", textBoxSirina.Text),
                        new XElement("Gaz", textBoxGaz.Text),
                        new XElement("Vrsta", comboBoxVrstaBrodaUB.Text),
                        new XElement("Zastava", comboBoxZastava.Text));

                Brodovi.Root.Add(Brod);
            }
            catch (Exception ex)
            {
                var Brodovi = new XDocument();
                Brodovi.Add(new XElement("Brod"));
                
                    var brod = new XElement("Korisnik",
                            new XElement("Ime", textBoxImeBroda.Text),
                            new XElement("Imo", textBoxImo.Text),
                            new XElement("Duzina", textBoxDuzina.Text),
                            new XElement("Sirina", textBoxSirina.Text),
                            new XElement("Gaz", textBoxGaz.Text),
                            new XElement("Vrsta", comboBoxVrstaBrodaUB.Text),
                            new XElement("Zastava", comboBoxZastava.Text));

                Brodovi.Root.Add(brod);
                
                Brodovi.Save(path);
            }

            textBoxImeBroda.Text = "";
            textBoxImo.Text = "";
            textBoxDuzina.Text = "";
            textBoxSirina.Text = "";
            textBoxGaz.Text = "";
            comboBoxVrstaBrodaUB.Text = "";
            comboBoxZastava.Text = "";


        }
    }
}
