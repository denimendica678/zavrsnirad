﻿
namespace vjezbaZavrsniRad
{
    partial class Upis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxDuzina = new System.Windows.Forms.TextBox();
            this.textBoxSirina = new System.Windows.Forms.TextBox();
            this.textBoxGaz = new System.Windows.Forms.TextBox();
            this.textBoxImeBroda = new System.Windows.Forms.TextBox();
            this.btnUnesiNoviBrod = new System.Windows.Forms.Button();
            this.comboBoxZastava = new System.Windows.Forms.ComboBox();
            this.comboBoxVrstaBrodaUB = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBoxNaslov = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnNatragUBUB = new System.Windows.Forms.Button();
            this.textBoxImo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.textBoxImo);
            this.groupBox2.Controls.Add(this.textBoxDuzina);
            this.groupBox2.Controls.Add(this.textBoxSirina);
            this.groupBox2.Controls.Add(this.textBoxGaz);
            this.groupBox2.Controls.Add(this.textBoxImeBroda);
            this.groupBox2.Controls.Add(this.btnUnesiNoviBrod);
            this.groupBox2.Controls.Add(this.comboBoxZastava);
            this.groupBox2.Controls.Add(this.comboBoxVrstaBrodaUB);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.richTextBoxNaslov);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.btnNatragUBUB);
            this.groupBox2.Location = new System.Drawing.Point(452, 105);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1107, 779);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // textBoxDuzina
            // 
            this.textBoxDuzina.Location = new System.Drawing.Point(204, 462);
            this.textBoxDuzina.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxDuzina.Name = "textBoxDuzina";
            this.textBoxDuzina.Size = new System.Drawing.Size(219, 22);
            this.textBoxDuzina.TabIndex = 26;
            // 
            // textBoxSirina
            // 
            this.textBoxSirina.Location = new System.Drawing.Point(204, 516);
            this.textBoxSirina.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxSirina.Name = "textBoxSirina";
            this.textBoxSirina.Size = new System.Drawing.Size(219, 22);
            this.textBoxSirina.TabIndex = 27;
            // 
            // textBoxGaz
            // 
            this.textBoxGaz.Location = new System.Drawing.Point(204, 567);
            this.textBoxGaz.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxGaz.Name = "textBoxGaz";
            this.textBoxGaz.Size = new System.Drawing.Size(219, 22);
            this.textBoxGaz.TabIndex = 28;
            // 
            // textBoxImeBroda
            // 
            this.textBoxImeBroda.Location = new System.Drawing.Point(204, 357);
            this.textBoxImeBroda.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxImeBroda.Name = "textBoxImeBroda";
            this.textBoxImeBroda.Size = new System.Drawing.Size(219, 22);
            this.textBoxImeBroda.TabIndex = 25;
            // 
            // btnUnesiNoviBrod
            // 
            this.btnUnesiNoviBrod.BackColor = System.Drawing.Color.Silver;
            this.btnUnesiNoviBrod.Location = new System.Drawing.Point(53, 687);
            this.btnUnesiNoviBrod.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUnesiNoviBrod.Name = "btnUnesiNoviBrod";
            this.btnUnesiNoviBrod.Size = new System.Drawing.Size(231, 46);
            this.btnUnesiNoviBrod.TabIndex = 24;
            this.btnUnesiNoviBrod.Text = "UNESI";
            this.btnUnesiNoviBrod.UseVisualStyleBackColor = false;
            this.btnUnesiNoviBrod.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBoxZastava
            // 
            this.comboBoxZastava.FormattingEnabled = true;
            this.comboBoxZastava.Items.AddRange(new object[] {
            "HRV",
            "ITA",
            "SRB",
            "BIH",
            "CG",
            "ALB",
            "GER",
            "FRA",
            "SPA",
            "POR",
            "ENG",
            "USA"});
            this.comboBoxZastava.Location = new System.Drawing.Point(204, 614);
            this.comboBoxZastava.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxZastava.Name = "comboBoxZastava";
            this.comboBoxZastava.Size = new System.Drawing.Size(219, 24);
            this.comboBoxZastava.TabIndex = 23;
            // 
            // comboBoxVrstaBrodaUB
            // 
            this.comboBoxVrstaBrodaUB.FormattingEnabled = true;
            this.comboBoxVrstaBrodaUB.Items.AddRange(new object[] {
            "Izletnicki",
            "Jahta",
            "Cruiser",
            "Ribarski"});
            this.comboBoxVrstaBrodaUB.Location = new System.Drawing.Point(204, 409);
            this.comboBoxVrstaBrodaUB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxVrstaBrodaUB.Name = "comboBoxVrstaBrodaUB";
            this.comboBoxVrstaBrodaUB.Size = new System.Drawing.Size(219, 24);
            this.comboBoxVrstaBrodaUB.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 516);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "ŠIRINA";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 567);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "GAZ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 614);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "ZASTAVA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 462);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "DUŽINA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 409);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "VRSTA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 357);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "IME";
            // 
            // richTextBoxNaslov
            // 
            this.richTextBoxNaslov.BackColor = System.Drawing.Color.Azure;
            this.richTextBoxNaslov.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxNaslov.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.richTextBoxNaslov.ForeColor = System.Drawing.Color.Navy;
            this.richTextBoxNaslov.Location = new System.Drawing.Point(365, 33);
            this.richTextBoxNaslov.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBoxNaslov.Name = "richTextBoxNaslov";
            this.richTextBoxNaslov.Size = new System.Drawing.Size(741, 78);
            this.richTextBoxNaslov.TabIndex = 7;
            this.richTextBoxNaslov.Text = "UPIS BRODA";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::vjezbaZavrsniRad.Properties.Resources.naslovna_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(267, 42);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(557, 246);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnNatragUBUB
            // 
            this.btnNatragUBUB.BackColor = System.Drawing.Color.Silver;
            this.btnNatragUBUB.Location = new System.Drawing.Point(53, 42);
            this.btnNatragUBUB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNatragUBUB.Name = "btnNatragUBUB";
            this.btnNatragUBUB.Size = new System.Drawing.Size(187, 89);
            this.btnNatragUBUB.TabIndex = 0;
            this.btnNatragUBUB.Text = "NATRAG";
            this.btnNatragUBUB.UseVisualStyleBackColor = false;
            this.btnNatragUBUB.Click += new System.EventHandler(this.btnBack1_Click);
            // 
            // textBoxImo
            // 
            this.textBoxImo.Location = new System.Drawing.Point(204, 308);
            this.textBoxImo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxImo.Name = "textBoxImo";
            this.textBoxImo.Size = new System.Drawing.Size(219, 22);
            this.textBoxImo.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(50, 308);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 17);
            this.label7.TabIndex = 30;
            this.label7.Text = "IMO";
            // 
            // Upis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.groupBox2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Upis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Upis broda";
            this.Load += new System.EventHandler(this.Upis_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnUnesiNoviBrod;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBoxNaslov;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnNatragUBUB;
        private System.Windows.Forms.TextBox textBoxDuzina;
        private System.Windows.Forms.TextBox textBoxSirina;
        private System.Windows.Forms.TextBox textBoxGaz;
        private System.Windows.Forms.ComboBox comboBoxZastava;
        private System.Windows.Forms.ComboBox comboBoxVrstaBrodaUB;
        public System.Windows.Forms.TextBox textBoxImeBroda;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox textBoxImo;
    }
}